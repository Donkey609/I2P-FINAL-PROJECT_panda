./vcpkg/bootstrap-vcpkg.bat
./vcpkg/vcpkg install allegro5
pause