#ifndef loading_scene_h
#define loading_scene_h

#include "utility.h"

Scene create_loading_scene(void);

#endif 