#ifndef menu_scene_h
#define menu_scene_h

#include "utility.h"

Scene create_menu_scene(void);

#endif /* menu_scene_h */
