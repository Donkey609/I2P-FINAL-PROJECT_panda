./vcpkg/bootstrap-vcpkg.sh
./vcpkg/vcpkg install allegro5
read -p "Press enter to continue"